---
title: "fantasy"
image_path: "images/fantasy.jpg"
---
Vo voľnom čase rád sledujem rôzne fantasy žánre od Lotr po Warcraft.

