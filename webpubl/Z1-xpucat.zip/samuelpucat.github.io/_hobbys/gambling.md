---
title: "gambling"
image_path: "images/gambling.jpg"
---
Zahrám si rád či už najnovšie hry, ale aj klasiky ako WoW.

