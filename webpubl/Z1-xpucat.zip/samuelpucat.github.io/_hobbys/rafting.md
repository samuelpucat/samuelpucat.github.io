---
title: "rafting"
image_path: "images/rafting.jpeg"
---
Splavujem každé leto Váh, Oravu niekedy aj Hron.

