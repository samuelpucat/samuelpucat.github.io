---
layout: post
title: "Konzultácia"
date: 2017-03-08
category: bakproj
toc: true
autor: "Samuel Púčať"
study: bc
class: 3.
semester: letný
week: 3.
about: "Konzultovanie analýzy bakalárskej práce."
---
# Prvá konzultácia v letnom semestri
## Pripomienky k analýze
* >vedúci bakalárskej práce mal niekoľko pripomienok na formálnu stránku analýzy: 
	* odkazy pripájať k publikáciám
	* premenovať aldebaransky robot NAO na NAO robot firmy SoftBank Robotics

## Prezentácia vypracovaného convertera *.rmo na *.xml 
* >vedúci bakalárskej práce schválil progress

## Odporúčania
* >vedúci bakalárskej práce odporúčil a vysvetlil ako robiť technickú dokumentáciu

